from appengine_django.models import BaseModel
from google.appengine.ext import db

# Create your models here.
